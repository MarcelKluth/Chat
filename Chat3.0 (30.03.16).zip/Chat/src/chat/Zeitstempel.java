package chat;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

public class Zeitstempel {

    static void printGregorianCalendarDate() {
        GregorianCalendar now = new GregorianCalendar();
        DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);   // 14.04.12
        df = DateFormat.getDateInstance(DateFormat.MEDIUM);             // 14.04.2012
        System.out.println(df.format(now.getTime()));
        df = DateFormat.getTimeInstance(DateFormat.SHORT);              // 21:21          
      
    }

    static void printSimpleDateFormat() {
        SimpleDateFormat formatter = new SimpleDateFormat("HH:mm");
        Date currentTime = new Date();
        System.out.println(formatter.format(currentTime));        // 2012.04.14 - 21:34:07 
    }

    public static void main(String[] args) {
        printGregorianCalendarDate();
        printSimpleDateFormat();
       
        
    }
} 

