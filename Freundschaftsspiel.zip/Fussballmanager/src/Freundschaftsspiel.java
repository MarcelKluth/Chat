
public interface Freundschaftsspiel{
String getHeimMannschaft();
String getGastMannschaft();
int getHeimPunkte();
int getGastPunkte();
String getErgebnisText();
}
