
public class Mannschaft {
	private String name;
	private Trainer trainer;
	private Torwart torwart;
	private Spieler[] kader;

	public Mannschaft(String n, Trainer t, Torwart tw, Spieler[] s){
		setName(n);
		setTrainer(t);
		setTorwart(tw);
		setKader(s);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Trainer getTrainer() {
		return trainer;
	}

	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}

	public Torwart getTorwart() {
		return torwart;
	}

	public void setTorwart(Torwart torwart) {
		this.torwart = torwart;
	}

	public Spieler[] getKader() {
		return kader;
	}

	public void setKader(Spieler[] kader) {
		this.kader = kader;
	}


	public int getStaerke(){
		int summ = 0;
		for (int i=0; i<10; i++)
			summ += kader[i].getStaerke();
		return summ/10;
	}

	public int getMotivation(){
		int summ = 0;
		for (int i=0; i<10; i++)
			summ += kader[i].getMotivation();
		return summ/10;
	}
}
