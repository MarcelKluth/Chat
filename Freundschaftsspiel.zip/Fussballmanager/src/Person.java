
public class Person {
	public String name;
	public int alter;
	
	public Person(String n, int a){
		this.name= n;
		this.alter= a;	
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAlter() {
		return alter;
	}
	public void setAlter(int alter) {
		this.alter = alter;
	}
	
	
}
