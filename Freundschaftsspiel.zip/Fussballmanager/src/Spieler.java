import java.util.Random;

public class Spieler extends Person {
	
	private int staerke;
	private int torschuss;
	private int motivation;
	private int tore;
	
	public Spieler(String n, int a, int s, int t, int m){
		super(n,a);
		setStaerke(s);
		setTorschuss(t);
		setMotivation(m);	
		
	}

	public int getStaerke() {
		return staerke;
	}

	public void setStaerke(int staerke) {
		this.staerke = staerke;
	}

	public int getTorschuss() {
		return torschuss;
	}

	public void setTorschuss(int torschuss) {
		this.torschuss = torschuss;
	}

	public int getMotivation() {
		return motivation;
	}

	public void setMotivation(int motivation) {
		this.motivation = motivation;
	}

	public int getTore() {
		return tore;
	}

	public void setTore(int tore) {
		this.tore = tore;
	}
	
	public void addTor(){
		this.tore++;
	}
	
	public int schiesstAufTor(){
		Random r = new Random();
		torschuss = Math.max(1, Math.min(10, torschuss - r.nextInt(3)));
		int ret = Math.max(1, Math.min(10, torschuss + r.nextInt(3)-1));
		return ret;
	}	
}
