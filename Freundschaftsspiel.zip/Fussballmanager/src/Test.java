
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Trainer trainer = new Trainer("Kevin", 2, 4);
		System.out.println(trainer.getName() + " " + trainer.getAlter() + " " + trainer.getErfahrung());
	}

}
