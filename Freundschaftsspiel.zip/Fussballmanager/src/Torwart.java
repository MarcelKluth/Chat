import java.util.Random;	
public class Torwart extends Spieler {
	private int reaktion;
	
	public Torwart(String n, int a, int s, int t, int m, int r){
		super(n, a, s, t, m);
		setReaktion(r);
		}

	public int getReaktion() {
		return reaktion;
	}

	public void setReaktion(int reaktion) {
		this.reaktion = reaktion;
	}
	
	
	public boolean haeltDenSchuss(int schuss){
		Random r = new Random();
		// +-1 ist hier die Varianz
		int ret = Math.max(1, Math.min(10, reaktion + r.nextInt(3)-1));
		if (ret>=schuss) {
			return true; // gehalten
		} else {
			return false; // TOR!!!
		}
	}
}
